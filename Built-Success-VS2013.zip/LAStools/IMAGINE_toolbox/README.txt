**************************************************************

  The LAStools LiDAR toolbox for ERDAS IMAGINE 2014 - 2016.1

  (c) 2014-2017 - martin.isenburg@rapidlasso.com

  rapidlasso GmbH - fast tools to catch reality

  legal details: http://lastools.org/LICENSE.txt

**************************************************************

Unzip the toolbox and follow the instructions. See this thread
for details or to ask questions:

http://groups.google.com/d/topic/lastools/QPXcEK7EXKM/discussion
http://rapidlasso.com/2015/04/08/lastools-toolbox-for-erdas-imagine-2014-released/
