--------------------------------------------------------------------------

  LASzip LiDAR compression DLL

--------------------------------------------------------------------------

  The LASzip LiDAR compressor packaged as a simple stand-alone DLL for
  easy inclusion of compression and decompression functionality into
  other software. It compresses LAS files into much more compact LAZ
  files and vice versa. The resulting files are around 7 - 20 percent
  of their original size. Follow the code in laszipdllexample.cpp for
  a simple example how to use the DLL.

  To get LASzip just download the LAStools distribution which contains
  the LASlib as well as the LASzip sources together with the binaries
  of the popular LAStools software and some small example LAZ files.

  http://laszip.org/
  http://lastools.org/
  http://rapidlasso.com/LAStools/

--------------------------------------------------------------------------

  PROGRAMMERS:
  
  martin@rapidlasso.com
  
--------------------------------------------------------------------------

  COPYRIGHT:
  
  (c) 2007-2017, martin isenburg, rapidlasso - fast tools to catch reality

--------------------------------------------------------------------------
